package com.example.exercise4;
import com.example.exercise4.R;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    TextView tvDisplay;
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tvDisplay = findViewById(R.id.tvDisplay);
        btnBack = findViewById(R.id.btnBack);

        // Get data from the Intent
        String name = getIntent().getStringExtra("USER_NAME");
        String movie = getIntent().getStringExtra("MOVIE_NAME");

        // Display the data
        tvDisplay.setText("Booking Confirmed!\n\nName: " + name + "\nMovie: " + movie + "\nLocation: Madurai");

        // Go back to the first page
        btnBack.setOnClickListener(v -> finish());
    }
}