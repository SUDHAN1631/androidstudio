package com.example.exercise4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText etName, etMovie;
    Button btnNext, btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etMovie = findViewById(R.id.etMovie);
        btnNext = findViewById(R.id.btnNextField);
        btnSubmit = findViewById(R.id.btnGoToSecond);

        // First button logic: Just a prompt to move to next field
        btnNext.setOnClickListener(v -> etMovie.requestFocus());

        // Second button: Send data to Page 2
        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String movie = etMovie.getText().toString();

            if(name.isEmpty() || movie.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("USER_NAME", name);
                intent.putExtra("MOVIE_NAME", movie);
                startActivity(intent);
            }
        });
    }
}