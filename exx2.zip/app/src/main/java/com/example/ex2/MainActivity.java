package com.example.ex2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    Button b1;
    Spinner s1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                    return insets;
                });
            e1=findViewById(R.id.e2);
            b1=findViewById(R.id.b2);
            s1=findViewById(R.id.spinner);
            b1.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    Bundle b=new Bundle();
                    Intent i=new Intent(MainActivity.this,MainActivity2.class);
                    b.putString("name",e1.getText().toString());
                    b.putString("dept",s1.getSelectedItem().toString());
                    i.putExtras(b);
                    startActivity(i);
                }

        });
    }
}